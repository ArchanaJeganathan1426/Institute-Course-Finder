# Institute & Course Finder

A Python Tkinter and MySQL based desktop application for searching, filtering, comparing, and managing institutes and courses.

## Features

- User course search
- Course-wise filtering
- Institute name search
- Fee range filtering
- Fee and duration sorting
- Institute details
- Course recommendations
- Admin login
- Add/delete institutes
- Add/delete courses
- View/delete user records

## Technologies

- Python
- Tkinter
- MySQL
- mysql-connector-python
- SQL

## Setup

1. Open MySQL.
2. Run `database.sql`.
3. Install the Python dependency:

```bash
pip install mysql-connector-python
```

4. Open `main.py`.
5. Replace `YOUR_MYSQL_PASSWORD` with your local MySQL password.
6. Run:

```bash
python main.py
```

## Admin Login

Username:

`admin`

Password:

`admin123`

## Project Structure

```text
Institute-Course-Finder/
├── main.py
├── database.sql
├── requirements.txt
└── README.md
```

## Author

Archana Jeganathan
